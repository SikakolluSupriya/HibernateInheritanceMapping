package com.klef.jfsd.HQL;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.MutationQuery;
import org.hibernate.query.Query;

public class HQLOperations 
{
   public static void main(String args[])
   {
	   HQLOperations operations = new HQLOperations();
	   //operations.addEmployee();
	   //operations.displayallempscompleteobject();
	   //operations.displayallempspartialobject();
	   //operations.aggregatefunctions();
	   
	   //operations.updatepositionalparams();
	   //operations.updatenamedparams();
	   
	   //operations.deletepositionalparams();
	   //operations.deletenamedparams();
	   
	   operations.hqldemo();
   }
   public void addEmployee()
   {
	 Configuration cfg = new Configuration();
	 cfg.configure("hibernate.cfg.xml");
	 
	 SessionFactory sf = cfg.buildSessionFactory();
	 Session session = sf.openSession();
	 
	 Transaction transaction = session.beginTransaction();
	 
	 Employee emp = new Employee();
	 emp.setEmpname("EP");
	 emp.setEmpdesignation("Professor");
	 emp.setEmpsalary(7000);
	 
 	 session.persist(emp);
 	 transaction.commit();
 	 System.out.println("Employee Added Successfully");
 	 
 	 session.close();
 	 sf.close();
   }
     
   
   public void displayallempscompleteobject()
   {
	   Configuration cfg = new Configuration();
	   cfg.configure("hibernate.cfg.xml");
		 
	   SessionFactory sf = cfg.buildSessionFactory();
	   Session session = sf.openSession();
		
	   String hql = "from Employee";
	   Query<Employee> qry = session.createQuery(hql, Employee.class);
	   List<Employee> emps =  qry.getResultList();
	   
	   System.out.println("Total Employees="+emps.size());
	   
	   for( Employee e :emps)
	   {
		   System.out.println("ID:"+e.getEmpid());
		   System.out.println("Name:"+e.getEmpname());
		   System.out.println("Designation:"+e.getEmpdesignation());
		   System.out.println("Salary:"+e.getEmpsalary());
	   }
	   session.close();
	   sf.close();
   }
   
   public void displayallempspartialobject()
   {
	   Configuration cfg = new Configuration();
	   cfg.configure("hibernate.cfg.xml");
		 
	   SessionFactory sf = cfg.buildSessionFactory();
	   Session session = sf.openSession();
		
	   String hql = "select e.empid,e.empname,e.empsalary from Employee e"; 
	   // e is an alias or reference object of type Employee
	   
	  Query<Object[]> qry =  session.createQuery(hql, Object[].class);
	  List<Object[]> emps = qry.getResultList();
	  
	  System.out.println("Total Employees="+emps.size());
	   
	  for(Object[] obj:emps)
	  {
		  System.out.println("ID:"+obj[0]);
		  System.out.println("Name:"+obj[1]);
		  System.out.println("Salary:"+obj[2]);
	  }
	  session.close();
	  sf.close();
   }
   public void aggregatefunctions()
   {
	   Configuration cfg = new Configuration();
	   cfg.configure("hibernate.cfg.xml");
		 
	   SessionFactory sf = cfg.buildSessionFactory();
	   Session session = sf.openSession();
	   
	   String hql1 = "select count(*) from Employee";
	   Query<Long> qry1 = session.createQuery(hql1,Long.class);
	   long count = qry1.getSingleResult();
	   System.out.println("Total Employees="+count);
	   
	   String hql2 = "select sum(empsalary) from Employee";
	   Query<Double> qry2 = session.createQuery(hql2,Double.class);
	   double totalsal = qry2.getSingleResult();
	   System.out.println("Total Salary="+totalsal);
	   
	   
	   session.close();
	   sf.close();
 
   }
   public void updatepositionalparams()
   {
	   Configuration cfg = new Configuration();
	   cfg.configure("hibernate.cfg.xml");
		 
	   SessionFactory sf = cfg.buildSessionFactory();
	   Session session = sf.openSession();
		 
	   Transaction transaction = session.beginTransaction();
	   
	   String hql = "update Employee set empname=?1,empsalary=?2 where empid=?3 ";
	  
	   MutationQuery qry = session.createMutationQuery(hql);
	   qry.setParameter(1, "EP");
	   qry.setParameter(2, 60000);
	   qry.setParameter(3, 1);
	   
	   int n = qry.executeUpdate();
	   
	   if(n>0)
	   {
		   System.out.println("Employee Updated Successfully");
	   }
	   else
	   {
		   System.out.println("Employee ID Not Found");
	   }
	   transaction.commit();
	   
	   session.close();
	   sf.close();  
	}
   public void updatenamedparams()
   {
	   Configuration cfg = new Configuration();
	   cfg.configure("hibernate.cfg.xml");
		 
	   SessionFactory sf = cfg.buildSessionFactory();
	   Session session = sf.openSession();
		 
	   Transaction transaction = session.beginTransaction();
	   
	   String hql = "update Employee set empname=:v1,empsalary=:v2 where empid=:v3 ";
	  
	   MutationQuery qry = session.createMutationQuery(hql);
	   qry.setParameter("v1", "KLEF");
	   qry.setParameter("v2", 50000);
	   qry.setParameter("v3", 1);
	   
	   int n = qry.executeUpdate();
	   
	   if(n>0)
	   {
		   System.out.println("Employee Updated Successfully");
	   }
	   else
	   {
		   System.out.println("Employee ID Not Found");
	   }
	   transaction.commit();
	   
	   session.close();
	   sf.close();  
	   
   }
   
   public void deletepositionalparams()
   {
	   Configuration cfg = new Configuration();
	   cfg.configure("hibernate.cfg.xml");
		 
	   SessionFactory sf = cfg.buildSessionFactory();
	   Session session = sf.openSession();
		 
	   Transaction transaction = session.beginTransaction();
	   
	   Scanner sc = new Scanner(System.in);
	   System.out.println("Enter EMP ID:");
	   int eid = sc.nextInt();
	   
	   String hql = "delete from Employee where empid=?1";
	  
	   MutationQuery qry = session.createMutationQuery(hql);
	   qry.setParameter(1, eid);
	   
	   int n = qry.executeUpdate();
	   
	   if(n>0)
	   {
		   System.out.println("Employee Deleted Successfully");
	   }
	   else
	   {
		   System.out.println("Employee ID Not Found");
	   }
	   transaction.commit();
	   
	   session.close();
	   sf.close(); 
	   sc.close();
	
   }
   public void deletenamedparams()
   {
	   Configuration cfg = new Configuration();
	   cfg.configure("hibernate.cfg.xml");
		 
	   SessionFactory sf = cfg.buildSessionFactory();
	   Session session = sf.openSession();
		 
	   Transaction transaction = session.beginTransaction();
	   
	   Scanner sc = new Scanner(System.in);
	   System.out.println("Enter EMP ID:");
	   int eid = sc.nextInt();
	   
	   String hql = "delete from Employee where empid=:v";
	  
	   MutationQuery qry = session.createMutationQuery(hql);
	   qry.setParameter("v", eid);
	   
	   int n = qry.executeUpdate();
	   
	   if(n>0)
	   {
		   System.out.println("Employee Deleted Successfully");
	   }
	   else
	   {
		   System.out.println("Employee ID Not Found");
	   }
	   transaction.commit();
	   
	   session.close();
	   sf.close();  
	   sc.close();
   }
   public void hqldemo()
   {
	   Configuration cfg = new Configuration();
	   cfg.configure("hibernate.cfg.xml");
		 
	   SessionFactory sf = cfg.buildSessionFactory();
	   Session session = sf.openSession();
		
	   String hql = "from Employee where empdesignation=?1 and empsalary>=?2";
	   
	   Query<Employee> qry = session.createQuery(hql, Employee.class);
	   
	   qry.setParameter(1, "Professor");
	   qry.setParameter(2, 10000);
	   
	   List<Employee> emps =  qry.getResultList();
	   
	   System.out.println("Total Employees="+emps.size());
	   
	   for( Employee e :emps)
	   {
		   System.out.println("ID:"+e.getEmpid());
		   System.out.println("Name:"+e.getEmpname());
		   System.out.println("Designation:"+e.getEmpdesignation());
		   System.out.println("Salary:"+e.getEmpsalary());
	   }
	   session.close();
	   sf.close();
   
   }
   public void pagination()
   {
     Configuration cfg = new Configuration();
     cfg.configure("hibernate.cfg.xml");
     
     SessionFactory sf = cfg.buildSessionFactory();
     Session session = sf.openSession();
    
     String hql = "from Employee";
     Query<Employee> qry = session.createQuery(hql, Employee.class);
     
     qry.setFirstResult(2);
     qry.setMaxResults(5);
     
     List<Employee> emps =  qry.getResultList();
     
     
     System.out.println("Total Employees="+emps.size());
     
     for( Employee e :emps)
     {
       System.out.println("ID:"+e.getEmpid());
       System.out.println("Name:"+e.getEmpname());
       System.out.println("Designation:"+e.getEmpdesignation());
       System.out.println("Salary:"+e.getEmpsalary());
     }
     session.close();
     sf.close();  
   }
}
   
   