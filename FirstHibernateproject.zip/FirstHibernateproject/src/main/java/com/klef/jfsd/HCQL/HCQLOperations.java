package com.klef.jfsd.HCQL;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;

public class HCQLOperations {
  public static void main(String[] args) {
    HCQLOperations operations=new HCQLOperations();
    //operations.addFaculty();
    //operations.restrictionsDemo();
    //operations.hcqldemo();
operations.aggregatefunctions();
}

  public void addFaculty()
     {
         Configuration cfg = new Configuration();
       cfg.configure("hibernate.cfg.xml");
       
       SessionFactory sf = cfg.buildSessionFactory();
       Session session = sf.openSession();
       
       Transaction transaction = session.beginTransaction();
       
       Faculty f = new Faculty();
       f.setId(109);
       f.setName("MSWD");
       f.setGender("MALE");
       f.setDepartment("CSE");
       f.setSalary(54009);
       f.setContactno("9701389479");
       
        session.persist(f);
        transaction.commit();
        System.out.println("Faculty Added Successfully");
        
        session.close();
        sf.close();
       
     }
  public void restrictionsDemo() {
    Configuration cfg = new Configuration();
       cfg.configure("hibernate.cfg.xml");
       
       SessionFactory sf = cfg.buildSessionFactory();
       Session session = sf.openSession();
       
       CriteriaBuilder cb = session.getCriteriaBuilder();
       CriteriaQuery<Faculty> cq=cb.createQuery(Faculty.class);
       //complete object - from Faculty
       Root<Faculty> root= cq.from(Faculty.class);
       //equals
      // cq.select(root).where(cb.equal(root.get("department"), "CSE"));
       
       //between
      // cq.select(root).where(cb.between(root.get("salary"), 10000,50000));
       //greater than or equal to
       cq.select(root).where(cb.ge(root.get("salary"), 30000));
       
       List<Faculty> facultylist = session.createQuery(cq).getResultList();
       System.out.println("Faculty Count="+facultylist.size());
       for(Faculty f:facultylist)
       {
         System.out.println(f.toString());
       }
       session.close();
       sf.close();
  }
//display faculty obj with salary gre than some value in desc order
  public void hcqldemo() {
	  Configuration cfg = new Configuration();
      cfg.configure("hibernate.cfg.xml");
      
      SessionFactory sf = cfg.buildSessionFactory();
      Session session = sf.openSession();
      
      CriteriaBuilder cb = session.getCriteriaBuilder();
      CriteriaQuery<Faculty> cq=cb.createQuery(Faculty.class);
      //complete object - from Faculty
      Root<Faculty> root= cq.from(Faculty.class);
      //restriction/criteria
      cq.select(root).where(cb.greaterThan(root.get("department"), 30000));
      //order by
      cq.orderBy(cb.desc(root.get("salary")));
      
      
  }
  public void aggregatefunctions() {
	 /* Configuration cfg = new Configuration();
  cfg.configure("hibernate.cfg.xml");
      
      SessionFactory sf = cfg.buildSessionFactory();
      Session session = sf.openSession();
      
      CriteriaBuilder cb = session.getCriteriaBuilder();
      CriteriaQuery<Long> cq=cb.createQuery(Long.class);
      //complete object - from Faculty
      Root<Faculty> root= cq.from(Faculty.class);
      cq.select(cb.count(root.get("name")));
      Long count = session.createQuery(cq).getSingleResult();
      System.out.println(count);
      
      session.close();
      sf.close();*/
 
	  Configuration cfg = new Configuration();
	  cfg.configure("hibernate.cfg.xml");
	      
	      SessionFactory sf = cfg.buildSessionFactory();
	      Session session = sf.openSession();
	      
	      CriteriaBuilder cb = session.getCriteriaBuilder();
	      
	      CriteriaQuery<Double> cq=cb.createQuery(Double.class);
	      
	      //complete object - from Faculty
	      Root<Faculty> root= cq.from(Faculty.class);
	      
	      cq.select(cb.sum(root.get("salary")));
	      
	      Double sum = session.createQuery(cq).getSingleResult();
	      
	      System.out.println(sum);
	      
	      session.close();
	      sf.close();
  }
  
}