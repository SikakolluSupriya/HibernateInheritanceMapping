package com.klu.FirstHibernateproject;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class Demo {
    public static void main(String[] args) {
        // Obtain SessionFactory
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();

        // Get student details by primary key value 1 using get() method
        Student st = session.get(Student.class, 1);
        if (st != null) {
            System.out.println("Using Get before update: " + st);
            
            // Begin transaction
            Transaction tx = session.beginTransaction();
            try {
                // Modify student details
                st.setFees(50000);
                session.merge(st); // Use merge() instead of update()
                tx.commit();
            } catch (Exception e) {
                if (tx != null) tx.rollback();
                System.out.println("Error during update: " + e.getMessage());
            }
        } else {
            System.out.println("Using get(): object not available");
        }

        // Using getReference() method (fetches proxy)
        try {
            Student st1 = session.getReference(Student.class, 2);
            // st1 is a proxy; it will trigger database access if any method is called on it
            System.out.println("Using getReference: " + st1);
        } catch (Exception e) {
            System.out.println("Using getReference: " + e.getMessage());
        }

        // Delete operation
        Student st2 = session.get(Student.class, 1);
        if (st2 != null) {
            System.out.println("Using Get before delete: " + st2);
            
            // Begin transaction
            Transaction tx = session.beginTransaction();
            try {
                // Delete student
                session.remove(st2); // Use remove() instead of delete()
                tx.commit();
            } catch (Exception e) {
                if (tx != null) tx.rollback();
                System.out.println("Error during delete: " + e.getMessage());
            }
        } else {
            System.out.println("Using get(): object not available");
        }

        // Using getReference() method to check if deleted data still exists
        try {
            Student st3 = session.getReference(Student.class, 2);
            // If the student was deleted, accessing properties will trigger an exception
            System.out.println("Using getReference after deletion: " + st3);
        } catch (Exception e) {
            System.out.println("Using getReference after deletion: " + e.getMessage());
        }

        session.close();
        sf.close();
    }
}
