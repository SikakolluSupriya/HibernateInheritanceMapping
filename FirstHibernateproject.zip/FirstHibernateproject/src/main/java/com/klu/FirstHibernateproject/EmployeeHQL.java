package com.klu.FirstHibernateproject;

import org.hibernate.Session; 
import org.hibernate.SessionFactory; 
  
 
 
public class EmployeeHQL { 
  
  public static void main(String[] args) { 
  SessionFactory sf = HibernateUtil.getSessionFactory(); 
  System.out.println(sf); 
  Session session = sf.openSession(); 
   
  //Query<Employee> q = session.createQuery("from Employee"); 
  //List<Employee> empList = q.list(); 
   
  //populate the emp details on console 
  //  for( Employee e : empList) 
  //   System.out.println(e); 
     
    //retrieving records based on some condition 
   session.getClass(); 
     
   
  } 
   
}