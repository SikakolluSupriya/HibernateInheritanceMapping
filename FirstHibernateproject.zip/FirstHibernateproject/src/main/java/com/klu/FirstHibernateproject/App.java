package com.klu.FirstHibernateproject;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App {
    public static void main(String[] args) {
        // Configure Hibernate
        Configuration cfg = new Configuration();
        cfg.configure(); // By default, this looks for hibernate.cfg.xml

        // Build the SessionFactory
        SessionFactory sf = cfg.buildSessionFactory();
        System.out.println(sf);

        // Open a session
        Session session = sf.openSession();

        // Create new Student and Product objects
        Student s = new Student();
        s.setSname("rishi");
        s.setCourse("jfsd");
        s.setFees(100000);

        Product p = new Product();
        p.setPname("banana");
        p.setPrice(1000);

        // Begin the transaction
        Transaction tx = session.beginTransaction();

        // Persist the objects into the database
        session.persist(s); // Use persist instead of save
        session.persist(p); // Use persist instead of save

        // Commit the transaction
        tx.commit();

        // Close the session and session factory
        session.close();
        sf.close();
    }
}
