package com.klu.FirstHibernateproject;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class Demo1 {
    public static void main(String[] args) {
        // Obtain SessionFactory
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session s = sf.openSession();

        // Get student details by primary key value 1 using get() method
        Student st = s.get(Student.class, 1);
        if (st != null) {
            System.out.println("Using get() before update: " + st);

            // Begin transaction
            Transaction tx = s.beginTransaction();
            try {
                // Modify student details
                st.setFees(50000); // No need to call update() explicitly
                tx.commit();
            } catch (Exception e) {
                if (tx != null) tx.rollback();
                System.out.println("Error during update: " + e.getMessage());
            }
        } else {
            System.out.println("Using get(): object not available");
        }

        // Using get() method for loading
        try {
            Student st1 = s.get(Student.class, 2);
            System.out.println("Using get(): " + st1);
        } catch (Exception e) {
            System.out.println("Using get(): " + e.getMessage());
        }

        // Delete operation
        Student st2 = s.get(Student.class, 1);
        if (st2 != null) {
            System.out.println("Using get() before delete: " + st2);

            // Begin transaction
            Transaction tx = s.beginTransaction();
            try {
                // Delete student
                s.remove(st2); // Use `remove()` method instead of `delete()`
                tx.commit();
            } catch (Exception e) {
                if (tx != null) tx.rollback();
                System.out.println("Error during delete: " + e.getMessage());
            }
        } else {
            System.out.println("Using get(): object not available");
        }

        // Using get() method to check if deleted data still exists
        try {
            Student st3 = s.get(Student.class, 2);
            System.out.println("Using get() after deletion: " + st3);
        } catch (Exception e) {
            System.out.println("Using get() after deletion: " + e.getMessage());
        }

        s.close();
        sf.close();
    }
}
