package InheritanceMapping;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class InheritanceDemo 
{
	
	public static void main(String[] args)
	{
		 Configuration cfg = new Configuration();
	       cfg.configure("hibernate.cfg.xml");
	       
	       SessionFactory sf = cfg.buildSessionFactory();
	       Session session = sf.openSession();
	       
	       Transaction transaction = session.beginTransaction();
	       
	       Person p = new Person();
	       p.setName("KLU");
	       p.setGender("FEMALE");
	       p.setAge(23);
	       p.setContactno("1234567895");
	       p.setLocation("VJA");
	       
	       Scholar s = new Scholar();
	       s.setDepartment("CSE");
	       s.setProgram("B.TECH");
	       s.setYear(2);
	       s.setCgpa(6.78);
	       s.setBacklogs(4);
	       s.setCounsellor("Nama sivayam");
	       
	       Teacher t = new Teacher();
	       t.setQualification("B.TECH");
	       t.setDepartment("ECE");
	       t.setDesignation("Professor");
	       t.setSalary(45000);
	       t.setExperience(5.6);
	       
	       session.persist(p);
	       session.persist(s);
	       session.persist(t);
	       
	       System.out.print("SUCCESS....!!!");
	       
	       transaction.commit();
	       session.close();
	       sf.close();
	}

}